//
// Created by Agustin Vazquez on 2019-06-23.
//

#ifndef GATSS_WRAPPER_H
#define GATSS_WRAPPER_H
#include "parser.h"
#include <stdlib.h>

int distribute_wrapper(Options options);
int recover_wrapper(Options options);
#endif //GATSS_WRAPPER_H
