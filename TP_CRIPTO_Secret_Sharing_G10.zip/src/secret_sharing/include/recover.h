//
// Created by Agustin Vazquez on 2019-06-19.
//

#ifndef GATSS_RECOVER_H
#define GATSS_RECOVER_H

#include "bmp.h"

void recover(char * filename, BMPImage **shadows, BMPImage *rw,uint32_t k, uint32_t n);

#endif //GATSS_RECOVER_H
