#!/bin/bash
mkdir gatSS
cd gatSS
cmake ..;
make
